package com.exampledemo.parsaniahardik.drawerfragmentdemonuts;

/**
 * Created by Parsania Hardik on 03-May-17.
 */
import android.content.Context;
import android.view.LayoutInflater;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.ArrayList;

public class DrawerAdapter extends RecyclerView.Adapter<DrawerAdapter.ViewHolder> {

    ArrayList<DrawerModel> arrayList = new ArrayList<>();
    private LayoutInflater inflater;
    private Context context;

    public DrawerAdapter(Context context,  ArrayList<DrawerModel> arrayList) {
        this.context = context;
        inflater = LayoutInflater.from(context);
        this.arrayList = arrayList;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.lv_item, parent, false);
        ViewHolder holder = new ViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {

        holder.title.setText(arrayList.get(position).getName());
        holder.ivicon.setImageResource(arrayList.get(position).getImage());
    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        TextView title;
        ImageView ivicon;

        public ViewHolder(View itemView) {
            super(itemView);
            title = (TextView) itemView.findViewById(R.id.name);
            ivicon = (ImageView) itemView.findViewById(R.id.ivicon);
        }
    }
}
