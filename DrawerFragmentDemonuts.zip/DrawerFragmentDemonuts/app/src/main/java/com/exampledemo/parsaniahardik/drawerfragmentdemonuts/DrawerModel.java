package com.exampledemo.parsaniahardik.drawerfragmentdemonuts;

/**
 * Created by Parsania Hardik on 03-May-17.
 */
public class DrawerModel {

    private String name;
    private int image;

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
